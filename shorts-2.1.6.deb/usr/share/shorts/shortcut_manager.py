#!/usr/bin/env python3
import os
import json
import stat
import subprocess
import logging
import traceback
import argparse
import sys
import time
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, filedialog
import json

# Set up logging
log_dir = os.path.expanduser('~/.local/share/shorts/logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'shorts.log')

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)

class ShortcutManager(ctk.CTk):
    def __init__(self):
        print("Starting initialization...")
        super().__init__()
        
        # Set up destruction flag
        self._destroyed = False
        self.protocol("WM_DELETE_WINDOW", self._on_destroy)

        # Configure the window
        self.title("shorts -- Debian Shortcuts Manager by 0HEX01")
        self.geometry("1200x600")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        
        # Define custom colors
        self.slate_grey = "#708090"
        self.gunmetal_blue = "#2C3539"
        self.bright_yellow = "#FFFF00"
        self.orange = "#FFA500"
        self.red = "#FF0000"

        # Create main frame
        self.main_frame = ctk.CTkScrollableFrame(self)
        self.main_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # Set window icon
        try:
            # Try system icon first
            icon_path = '/usr/share/icons/hicolor/256x256/apps/shorts.png'
            if os.path.exists(icon_path):
                self.iconphoto(True, tk.PhotoImage(file=icon_path))
            else:
                # Fallback to old location
                icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icon.png')
                if os.path.exists(icon_path):
                    self.iconphoto(True, tk.PhotoImage(file=icon_path))
        except Exception as e:
            print(f"Error setting icon: {str(e)}")

        # Define shortcut directories and their descriptions and tab names
        self.shortcut_dirs = {
            '/usr/local/bin': {'desc': 'Local/Custom Programs', 'tab': 'Local Bin', 'readonly': False},
            '/usr/bin': {'desc': 'System Programs', 'tab': 'System Bin', 'readonly': True},
            '/bin': {'desc': 'Essential Commands', 'tab': 'Core Bin', 'readonly': True},
            '/usr/sbin': {'desc': 'System Admin Tools', 'tab': 'System Admin', 'readonly': True},
            '/sbin': {'desc': 'Essential System Tools', 'tab': 'Core Admin', 'readonly': True}
        }
        
        # Create /usr/local/bin if it doesn't exist (only non-system directory)
        if not os.path.exists('/usr/local/bin'):
            try:
                os.makedirs('/usr/local/bin', exist_ok=True)
            except Exception as e:
                logging.error(f"Failed to create /usr/local/bin: {e}")
        
        # Track system directories that should be read-only
        self.system_dirs = {'/usr/bin', '/bin', '/usr/sbin', '/sbin'}

        # Initialize shortcuts data
        # Use the real user's home directory, not root's
        real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
        if real_user == 'root' and os.getenv('SUDO_USER'):
            real_user = os.getenv('SUDO_USER')
            self.shortcuts_file = os.path.join('/home', real_user, '.shortcuts.json')
        else:
            self.shortcuts_file = os.path.expanduser('~/.shortcuts.json')
        self.shortcuts = self.load_shortcuts()

        # Initialize editing state
        self.editing_shortcut = None

        # Import existing scripts
        self.import_existing_scripts()

        # Create widgets
        self.create_widgets()

        # Create save/load buttons
        self.create_save_load_buttons()

        # Create tabview for shortcuts
        self.create_shortcut_tabs()

        # Bind mouse wheel events
        self.bind_mouse_events()

        # Update shortcuts list
        self.update_shortcuts_list()

    def log_command(self, command, status="Running"):
        """Log a command to the system log"""
        timestamp = time.strftime("%H:%M:%S")
        logging.info(f"[{timestamp}] {status}: {command}")

    def bind_mouse_events(self):
        """Set up mouse wheel scrolling for all tabs"""
        def _on_mousewheel(event):
            widget = event.widget
            while widget and not hasattr(widget, '_parent_canvas'):
                widget = widget.master
            if not widget:
                return

            canvas = widget._parent_canvas
            if not canvas:
                return

            # Handle different mouse types
            if event.num == 4 or (hasattr(event, 'delta') and event.delta > 0):
                canvas.yview_scroll(-1, "units")
            elif event.num == 5 or (hasattr(event, 'delta') and event.delta < 0):
                canvas.yview_scroll(1, "units")

        def _bind_recursive(widget):
            widget.bind_all('<Button-4>', _on_mousewheel)
            widget.bind_all('<Button-5>', _on_mousewheel)
            widget.bind_all('<MouseWheel>', _on_mousewheel)

        # Set up scrolling for each tab
        for directory in self.shortcut_dirs.keys():
            tab_name = self.shortcut_dirs[directory]['tab']
            frame = getattr(self, f'shortcuts_frame_{tab_name}')
            _bind_recursive(frame)

    def create_save_load_buttons(self):
        """Create buttons for saving and loading shortcuts"""
        save_load_frame = ctk.CTkFrame(self.main_frame)
        save_load_frame.pack(padx=5, pady=5, fill="x")

        save_button = ctk.CTkButton(
            save_load_frame,
            text="Save Shortcuts",
            command=self.save_shortcuts_to_file,
            fg_color=self.slate_grey,
            hover_color=self.gunmetal_blue
        )
        save_button.pack(side="left", padx=5, pady=5)

        load_button = ctk.CTkButton(
            save_load_frame,
            text="Load Shortcuts",
            command=self.load_shortcuts_from_file,
            fg_color=self.slate_grey,
            hover_color=self.gunmetal_blue
        )
        load_button.pack(side="left", padx=5, pady=5)

    def save_shortcuts_to_file(self):
        """Save shortcuts to a .dsm file"""
        file_path = filedialog.asksaveasfilename(
            defaultextension=".dsm",
            filetypes=[("Debian Shortcut Manager", "*.dsm")],
            title="Save Shortcuts"
        )
        if file_path:
            try:
                # Convert shortcuts to a more readable format
                formatted_shortcuts = {}
                for name, data in self.shortcuts.items():
                    formatted_shortcuts[name] = {
                        'command': data['command'],
                        'directory': data.get('directory', '/usr/local/bin'),
                        'background': data.get('background', False),
                        'sudo': data.get('sudo', False)
                    }

                messagebox.showinfo("Success", "Shortcuts imported successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to import shortcuts: {str(e)}")

    def load_shortcuts_from_file(self):
        """Load shortcuts from a directory"""
        directory = filedialog.askdirectory(
            title="Select Directory with Executable Files"
        )
        if directory:
            try:
                # Import executables from the selected directory
                if os.path.exists(directory):
                    self.shortcut_dirs[directory] = True
                    self.import_existing_scripts()
                    messagebox.showinfo("Success", "Shortcuts loaded from directory!")
                else:
                    messagebox.showerror("Error", "Selected directory does not exist")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load shortcuts: {str(e)}")

    def create_widgets(self):
        print("Starting widget creation...")
        # Create top frame for input area and terminal
        self.scroll_frame = ctk.CTkFrame(self.main_frame)
        self.scroll_frame.pack(padx=5, pady=5, fill="x", expand=False)
        print("Created scroll frame")

        # Create horizontal layout frame
        self.horizontal_frame = ctk.CTkFrame(self.scroll_frame)
        self.horizontal_frame.pack(fill="x", expand=True)

        # Left side - Input frame
        self.input_frame = ctk.CTkFrame(self.horizontal_frame)
        self.input_frame.pack(side="left", padx=5, pady=5, fill="y")

        # Right side - Terminal frame
        self.terminal_frame = ctk.CTkFrame(self.horizontal_frame)
        self.terminal_frame.pack(side="right", padx=5, pady=5, fill="both", expand=True)

        # Terminal output label
        self.terminal_label = ctk.CTkLabel(self.terminal_frame, text="Command Output:")
        self.terminal_label.pack(padx=5, pady=(5,0), anchor="w")

        # Terminal output text widget
        self.terminal_output = ctk.CTkTextbox(self.terminal_frame, width=400, height=150)
        self.terminal_output.pack(padx=5, pady=5, fill="both", expand=True)
        self.terminal_output.configure(state="disabled")

        # Shortcut name entry
        self.name_label = ctk.CTkLabel(self.input_frame, text="Shortcut Name:")
        self.name_label.pack(padx=5, pady=5, anchor="w")
        self.name_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.name_entry.pack(padx=5, pady=5, anchor="w")

        # Command entry
        self.command_label = ctk.CTkLabel(self.input_frame, text="Command:")
        self.command_label.pack(padx=5, pady=5, anchor="w")
        self.command_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.command_entry.pack(padx=5, pady=5, anchor="w")

        # Background checkbox
        self.background_var = ctk.BooleanVar()
        self.background_check = ctk.CTkCheckBox(self.input_frame, text="Run in background",
                                              variable=self.background_var)
        self.background_check.pack(padx=5, pady=5, anchor="w")

        # Passwordless sudo checkbox
        self.sudo_var = ctk.BooleanVar()
        self.sudo_check = ctk.CTkCheckBox(self.input_frame, text="Enable passwordless sudo",
                                        variable=self.sudo_var)
        self.sudo_check.pack(padx=5, pady=5, anchor="w")

        # Directory-specific add buttons frame with grid layout
        self.buttons_frame = ctk.CTkFrame(self.main_frame)
        self.buttons_frame.pack(padx=5, pady=5, fill="x")

        # Create a button grid (3x2)
        directories = list(self.shortcut_dirs.items())
        for i in range(2):  # rows
            for j in range(3):  # columns
                idx = i * 3 + j
                if idx < len(directories):
                    directory, info = directories[idx]
                    button_frame = ctk.CTkFrame(self.buttons_frame)
                    button_frame.grid(row=i, column=j, padx=5, pady=5, sticky="nsew")

                    button = ctk.CTkButton(
                        button_frame,
                        text=f"Add to {info['tab']}",
                        command=lambda d=directory: self.add_shortcut(d),
                        width=200,  # Smaller width
                        fg_color=self.slate_grey,
                        hover_color=self.gunmetal_blue
                    )
                    button.pack(padx=5, pady=(5,0))

                    desc_label = ctk.CTkLabel(
                        button_frame,
                        text=info['desc'],
                        font=("Helvetica", 10)
                    )
                    desc_label.pack(padx=5, pady=(0,5))

        # Configure grid weights
        for i in range(2):
            self.buttons_frame.grid_rowconfigure(i, weight=1)
        for j in range(3):
            self.buttons_frame.grid_columnconfigure(j, weight=1)

        self.buttons_frame = ctk.CTkFrame(self.input_frame)
        self.buttons_frame.pack(padx=5, pady=5, fill="x")

        # Add/Save button
        self.action_button = ctk.CTkButton(self.buttons_frame, text="Add Shortcut",
                                         command=self.add_or_update_shortcut,
                                         fg_color=self.slate_grey,
                                         hover_color=self.gunmetal_blue)
        self.action_button.pack(side="left", padx=5)

        # Cancel button (hidden by default)
        self.cancel_button = ctk.CTkButton(self.buttons_frame, text="Cancel",
                                         command=self.cancel_edit,
                                         fg_color=self.slate_grey,
                                         hover_color=self.gunmetal_blue)
        
    def create_shortcut_tabs(self):
        # Create tabview
        self.tabview = ctk.CTkTabview(self.main_frame)
        self.tabview.pack(padx=5, pady=5, fill="both", expand=True)

        # Create a tab for each directory
        for directory in self.shortcut_dirs.keys():
            tab_name = self.shortcut_dirs[directory]['tab']
            self.tabview.add(tab_name)
            
            # Create scrollable frame for this tab
            frame = ctk.CTkScrollableFrame(self.tabview.tab(tab_name))
            frame.pack(padx=5, pady=5, fill="both", expand=True)

            # Store the frame reference
            setattr(self, f'shortcuts_frame_{tab_name}', frame)

    def update_shortcuts_list(self):
        try:
            # Check if window still exists
            if not self.winfo_exists():
                return
                
            # Clear existing items in all tabs
            for directory in self.shortcut_dirs.keys():
                tab_name = self.shortcut_dirs[directory]['tab']
                frame = getattr(self, f'shortcuts_frame_{tab_name}')
                
                # Check if frame still exists
                if not frame.winfo_exists():
                    continue
                    
                for widget in frame.winfo_children():
                    widget.destroy()
                
                # Add header
                header_frame = ctk.CTkFrame(frame)
                header_frame.pack(padx=5, pady=5, fill="x")
                ctk.CTkLabel(header_frame, text="Name", width=150).pack(side="left", padx=5)
                ctk.CTkLabel(header_frame, text="Command", width=400).pack(side="left", padx=5)

                # Add shortcuts for this directory
                shortcuts_added = 0
                for name, data in sorted(self.shortcuts.items()):
                    script_path = os.path.join(data.get('directory', '/usr/local/bin'), name)
                    if data.get('directory', '/usr/local/bin') == directory:
                        if not os.path.exists(script_path):
                            continue

                        shortcut_frame = ctk.CTkFrame(frame)
                        shortcut_frame.pack(padx=5, pady=2, fill="x")

                        name_label = ctk.CTkLabel(shortcut_frame, text=name, width=150)
                        name_label.pack(side="left", padx=5)

                        command_label = ctk.CTkLabel(shortcut_frame, text=data['command'], width=400, wraplength=400, justify="left")
                        command_label.pack(side="left", padx=5)

                        edit_btn = ctk.CTkButton(
                            shortcut_frame,
                            text="Edit",
                            width=60,
                            command=lambda n=name: self.edit_shortcut(n),
                            fg_color=self.orange,
                            hover_color=self.bright_yellow,
                            text_color="black"
                        )
                        edit_btn.pack(side="left", padx=5)

                        delete_btn = ctk.CTkButton(
                            shortcut_frame,
                            text="Delete",
                            width=60,
                            command=lambda n=name: self.delete_shortcut(n),
                            fg_color=self.orange,
                            hover_color=self.red,
                            text_color="black"
                        )
                        delete_btn.pack(side="left", padx=5)
                        shortcuts_added += 1

                frame.update()

            # Rebind mouse events after updating all tabs
            self.bind_mouse_events()

        except tk.TclError:
            # Window has been destroyed
            pass
        except Exception as e:
            error_msg = f"Error updating shortcuts list: {str(e)}"
            logging.error(error_msg)

    def import_existing_scripts(self):
        try:
            logging.info('Starting import of existing scripts')
            
            # First, remove any shortcuts that don't exist in their directories
            to_remove = []
            for name, data in self.shortcuts.items():
                script_path = os.path.join(data.get('directory', '/usr/local/bin'), name)
                if not os.path.exists(script_path):
                    to_remove.append(name)
            
            for name in to_remove:
                del self.shortcuts[name]
            
            # Scan all directories
            for directory in self.shortcut_dirs.keys():
                if not os.path.exists(directory):
                    logging.warning(f'Directory not found: {directory}')
                    continue
                
                # Try to read directory with sudo if needed
                try:
                    if not os.access(directory, os.R_OK):
                        result = subprocess.run(['sudo', 'ls', directory], capture_output=True, text=True)
                        files = result.stdout.splitlines()
                    else:
                        files = os.listdir(directory)
                except Exception as e:
                    logging.error(f"Error reading {directory}: {str(e)}")
                    continue
                    
                for file in files:
                    # Skip the shorts launcher itself
                    if file == 'shorts':
                        continue

                    file_path = os.path.join(directory, file)
                    
                    # Only check if it exists and is executable, no file reading
                    if os.path.isfile(file_path) and os.access(file_path, os.X_OK):
                        self.shortcuts[file] = {
                            'command': file,
                            'directory': directory
                        }

            # Save the updated shortcuts
            self.save_shortcuts()
            logging.info('Finished importing existing scripts')

        except Exception as e:
            self.log_error("Error during script import", e)

    def load_shortcuts(self):
        # Start with an empty dict
        return {}

    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Handle uncaught exceptions"""
        error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logging.error(f'Uncaught exception:\n{error_msg}')
        messagebox.showerror('Error', f'An unexpected error occurred. Check {log_file} for details.')

    def log_error(self, message, error):
        """Log error with traceback and show user-friendly message"""
        logging.error(f'{message}:\n{traceback.format_exc()}')
        messagebox.showerror('Error', f'{message}\n{str(error)}\nCheck {log_file} for details.')

    def save_shortcuts(self):
        # No need to save shortcuts since we're just using executable files
        pass

    def _on_destroy(self):
        """Handle window destruction"""
        self._destroyed = True
        self.quit()
        
    def needs_sudo(self, command):
        """Check if a command likely needs sudo privileges"""
        sudo_keywords = [
            'apt', 'dpkg', 'systemctl', 'service', 'mount', 'umount', 'fdisk',
            'parted', 'mkfs', 'fsck', 'iptables', 'ufw', 'usermod', 'useradd',
            'userdel', 'groupadd', 'groupdel', 'chown', 'chmod', 'chgrp',
            '/etc/', '/var/', '/usr/', '/boot/', 'docker', 'timeshift'
        ]
        return any(keyword in command.lower() for keyword in sudo_keywords)

    def create_shortcut_script(self, name, command, background):
        # Only allow creating shortcuts in /usr/local/bin
        script_path = f"/usr/local/bin/{name}"
        
        try:
            # Check if target is in a system directory
            target_dir = os.path.dirname(command)
            if target_dir in self.system_dirs:
                error_msg = "Cannot modify system directories. Please use /usr/local/bin for custom shortcuts."
                logging.error(error_msg)
                messagebox.showerror("Error", error_msg)
                return False
                
            # Create a symlink to the command
            try:
                os.symlink(command, script_path)
            except FileExistsError:
                # Only remove if it's in /usr/local/bin
                if os.path.dirname(script_path) == '/usr/local/bin':
                    os.remove(script_path)
                    os.symlink(command, script_path)
                else:
                    error_msg = "Cannot modify system files"
                    logging.error(error_msg)
                    messagebox.showerror("Error", error_msg)
                    return False
            
            # Log success
            logging.info(f"Created shortcut '{name}' -> {command}")
            return True
            
        except Exception as e:
            error_msg = f"Failed to create shortcut: {str(e)}"
            logging.error(error_msg)
            messagebox.showerror("Error", error_msg)
            return False

    def add_to_sudoers(self, name):
        try:
            # Create a new sudoers file for the shortcut
            sudoers_path = f"/etc/sudoers.d/{name}"
            username = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            
            # Create the sudoers entry
            sudoers_content = f"{username} ALL=(ALL) NOPASSWD: /usr/local/bin/{name}\n"
            
            # Write to a temporary file first
            temp_path = f"/tmp/{name}.sudoers"
            with open(temp_path, 'w') as f:
                f.write(sudoers_content)
            
            # Use visudo to safely install the file
            result = subprocess.run(['sudo', 'visudo', '-c', '-f', temp_path], capture_output=True, text=True)
            if result.returncode == 0:
                subprocess.run(['sudo', 'mv', temp_path, sudoers_path])
                subprocess.run(['sudo', 'chmod', '0440', sudoers_path])
            else:
                os.unlink(temp_path)
                messagebox.showerror("Error", f"Invalid sudoers entry: {result.stderr}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to configure sudoers: {str(e)}")

    def add_shortcut(self, directory):
        # Debug logging
        self.log_command(f"Attempting to add shortcut to directory: {directory}", "Info")
        
        # Get form values
        name = self.name_entry.get().strip() if self.name_entry else ""
        command = self.command_entry.get().strip() if self.command_entry else ""
        background = self.background_var.get() if hasattr(self, 'background_var') else False
        sudo = self.sudo_var.get() if hasattr(self, 'sudo_var') else False

        # Debug logging
        self.log_command(f"Form values - Name: '{name}', Command: '{command}'", "Debug")

        if not name or not command:
            self.log_command(f"Failed to create shortcut: Name and command are required", "Error")
            messagebox.showerror("Error", "Name and command are required")
            return

        if not name.isalnum() and not '_' in name:
            self.log_command(f"Failed to create shortcut: Name must be alphanumeric", "Error")
            messagebox.showerror("Error", "Name must be alphanumeric (underscores allowed)")
            return

        if name in self.shortcuts:
            self.log_command(f"Failed to create shortcut: '{name}' already exists", "Error")
            messagebox.showerror("Error", f"Shortcut '{name}' already exists")
            return

        try:
            # Log the attempt
            self.log_command(f"Creating shortcut '{name}' for command: {command}", "Info")

            # Create the script
            if not self.create_shortcut_script(name, command, background):
                self.log_command(f"Failed to create script for '{name}'", "Error")
                return

            # Add to sudoers if needed
            if sudo:
                self.log_command(f"Adding '{name}' to sudoers", "Info")
                self.add_to_sudoers(name)

            # Save to file
            self.shortcuts[name] = {
                'command': command,
                'background': background,
                'sudo': sudo,
                'directory': directory
            }
            self.save_shortcuts()
            self.log_command(f"Shortcut '{name}' saved to configuration", "Success")

            # Clear form and update UI
            self.clear_form()
            self.update_shortcuts_list()

            messagebox.showinfo("Success", f"Shortcut '{name}' created successfully")

        except Exception as e:
            error_msg = f"Error creating shortcut '{name}': {str(e)}"
            self.log_command(error_msg, "Error")
            self.log_error(error_msg, e)

    def add_or_update_shortcut(self):
        name = self.name_entry.get().strip()
        command = self.command_entry.get().strip()
        background = self.background_var.get()

        if not name or not command:
            messagebox.showerror("Error", "Name and command are required!")
            return

        if not name.isalnum() and not '_' in name:
            messagebox.showerror("Error", "Name must be alphanumeric (underscores allowed)")
            return

        if hasattr(self, 'old_shortcut_name') and self.old_shortcut_name != name:
            # Delete old shortcut if name changed
            self.delete_shortcut(self.old_shortcut_name, update_ui=False)

        if self.create_shortcut_script(name, command, background):
            self.shortcuts[name] = {
                'command': command,
                'background': background
            }
            self.save_shortcuts()
            self.update_shortcuts_list()
            self.clear_form()

    def clear_form(self):
        self.name_entry.delete(0, 'end')
        self.command_entry.delete(0, 'end')
        self.background_var.set(False)
        self.sudo_var.set(False)  # Reset sudo checkbox
        self.action_button.configure(text="Add Shortcut")
        self.cancel_button.pack_forget()
        self.editing_shortcut = None
        if hasattr(self, 'old_shortcut_name'):
            del self.old_shortcut_name
        # Log the form clear
        self.log_command("Form cleared", "Info")

    def cancel_edit(self):
        self.clear_form()

    def edit_shortcut(self, name):
        if name in self.shortcuts:
            self.editing_shortcut = name
            data = self.shortcuts[name]
            
            self.name_entry.delete(0, 'end')
            self.name_entry.insert(0, name)
            
            self.command_entry.delete(0, 'end')
            self.command_entry.insert(0, data['command'])
            
            self.background_var.set(data['background'])
            
            self.action_button.configure(text="Save Changes")
            self.cancel_button.pack(side="left", padx=5)
            
            # Save the old name for deletion if name changes
            self.old_shortcut_name = name

    def delete_shortcut(self, name, update_ui=True):
        if name in self.shortcuts:
            script_path = f"/usr/local/bin/{name}"
            sudoers_path = f"/etc/sudoers.d/{name}"
            try:
                # Remove the script
                os.remove(script_path)
                
                # Remove sudoers file if it exists
                if os.path.exists(sudoers_path):
                    subprocess.run(['sudo', 'rm', '-f', sudoers_path])
                
                del self.shortcuts[name]
                self.save_shortcuts()
                if update_ui:
                    self.update_shortcuts_list()
            except PermissionError:
                messagebox.showerror("Error", "Permission denied. Try running with sudo.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete shortcut: {str(e)}")



def list_shortcuts(shortcuts_file):
    """List all available shortcuts"""
    # Just check executable files in standard directories
    for directory in ['/usr/local/bin', '/usr/bin', '/bin']:
        if os.path.exists(directory):
            print(f"\nExecutables in {directory}:")
            for file in os.listdir(directory):
                file_path = os.path.join(directory, file)
                if os.path.isfile(file_path) and os.access(file_path, os.X_OK):
                    print(f"  {file}")
                print(f"  {name}: {data['command']}{bg}")
    else:
        print("No shortcuts found.")

def print_usage_examples():
    """Print usage examples for the shorts command"""
    examples = """
Usage Examples:
  1. Launch GUI:
    $ shorts

  2. List all shortcuts:
    $ shorts --list

  3. Quick shortcut creation:
    $ shorts 'shortcut-name' 'command1 -flag1 ; command2 -flag2'

  4. Add a new shortcut with flags:
    $ shorts --add --name="shortcut-name" --cmd="command" [--background]

  5. Show this help:
    $ shorts --help

Practical Examples:
  1. System update shortcut:
    $ shorts 'update-sys' 'apt update ; apt upgrade -y ; apt autoremove -y'

  2. Network service restart:
    $ shorts 'net-restart' 'systemctl restart NetworkManager ; service networking restart'

  3. Multiple sudo commands:
    $ shorts 'fix-dns' 'sudo rm /etc/resolv.conf ; sudo ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf'

  4. Background service with logging:
    $ shorts 'start-vpn' 'openvpn --config /etc/openvpn/client.ovpn > /var/log/vpn.log 2>&1' --background

  5. Development environment setup:
    $ shorts 'dev-env' 'docker-compose up -d ; npm install ; npm run dev'

  6. System maintenance:
    $ shorts 'maintain' 'bleachbit -c --preset ; timeshift --create'

Notes:
  - Use quotes around commands with spaces or special characters
  - Separate multiple commands with semicolons
  - Add --background for long-running or service-type commands
  - Shortcuts are stored in ~/.shortcuts.json
  - Scripts are created in /usr/local/bin/
    """
    print(examples)

def main():
    parser = argparse.ArgumentParser(
        description="Shortcut Manager - Create and manage system shortcuts",
        epilog="Run without arguments to launch the GUI")
    
    # Positional arguments for quick shortcut creation
    parser.add_argument('shortcut_name', nargs='?',
                        help='Shortcut name for quick creation')
    parser.add_argument('command', nargs='?',
                        help='Command for quick creation')
    
    # Optional arguments
    parser.add_argument('--list', '-l', action='store_true',
                        help='List all available shortcuts')
    parser.add_argument('--add', '-a', action='store_true',
                        help='Add a new shortcut')
    parser.add_argument('--name', '-n',
                        help='Name for the new shortcut (with --add)')
    parser.add_argument('--cmd', '-c',
                        help='Command for the new shortcut (with --add)')
    parser.add_argument('--background', '-b', action='store_true',
                        help='Run the command in background')
    parser.add_argument('--examples', '-e', action='store_true',
                        help='Show usage examples')

    args = parser.parse_args()

    # Get the shortcuts file path
    real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
    if real_user == 'root' and os.getenv('SUDO_USER'):
        real_user = os.getenv('SUDO_USER')
        shortcuts_file = os.path.join('/home', real_user, '.shortcuts.json')
    else:
        shortcuts_file = os.path.expanduser('~/.shortcuts.json')

    if args.examples:
        print_usage_examples()
        return

    if args.list:
        list_shortcuts(shortcuts_file)
        return

    # Handle quick shortcut creation with positional arguments
    if args.shortcut_name and args.command:
        app = ShortcutManager()
        app.create_shortcut_script(args.shortcut_name, args.command, args.background)
        return

    # Handle --add with named arguments
    if args.add:
        if not args.name or not args.cmd:
            print("Error: Both --name and --cmd are required when using --add")
            parser.print_help()
            return
        app = ShortcutManager()
        app.create_shortcut_script(args.name, args.cmd, args.background)
        return

    # If no command-line actions specified, launch GUI
    if not any([args.shortcut_name, args.command, args.list, args.add, args.examples]):
        app = ShortcutManager()
        app.mainloop()

if __name__ == "__main__":
    main()
