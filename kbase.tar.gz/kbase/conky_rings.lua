require 'cairo'

function conky_main()
    if conky_window == nil then
        return
    end
    
    local cs = cairo_xlib_surface_create(conky_window.display,
                                       conky_window.drawable,
                                       conky_window.visual,
                                       conky_window.width,
                                       conky_window.height)
    local display = cairo_create(cs)
    
    local updates = conky_parse('${updates}')
    update_num = tonumber(updates)
    
    if update_num > 5 then
        draw_rings(display)
    end
    
    cairo_surface_destroy(cs)
    cairo_destroy(display)
end

function draw_ring(display, value, max_value, x, y, radius, thickness, start_angle, end_angle, bg_color, fg_color)
    local angle = value * (end_angle - start_angle) / max_value + start_angle
    
    -- Draw background ring
    cairo_set_source_rgba(display, bg_color[1], bg_color[2], bg_color[3], 0.2)
    cairo_set_line_width(display, thickness)
    cairo_arc(display, x, y, radius, start_angle, end_angle)
    cairo_stroke(display)
    
    -- Draw indicator
    cairo_set_source_rgba(display, fg_color[1], fg_color[2], fg_color[3], 1.0)
    cairo_arc(display, x, y, radius, start_angle, angle)
    cairo_stroke(display)
end

function draw_rings(display)
    local center_x = 90
    local center_y = 120
    local radius = 30
    local thickness = 10
    local start_angle = 0
    local end_angle = 2 * math.pi
    
    -- CPU ring
    local cpu = tonumber(conky_parse('${cpu}'))
    draw_ring(display, cpu, 100, center_x, center_y, radius, thickness,
             start_angle, end_angle,
             {0.5, 0.5, 0.5},  -- Background color (gray)
             {0.55, 0.69, 0.35}) -- Foreground color (green)
    
    -- Memory ring
    local mem = tonumber(conky_parse('${memperc}'))
    draw_ring(display, mem, 100, center_x, center_y + 80, radius, thickness,
             start_angle, end_angle,
             {0.5, 0.5, 0.5},
             {0.55, 0.69, 0.35})
    
    -- Disk ring
    local disk = tonumber(conky_parse('${fs_used_perc /}'))
    draw_ring(display, disk, 100, center_x, center_y + 160, radius, thickness,
             start_angle, end_angle,
             {0.5, 0.5, 0.5},
             {0.55, 0.69, 0.35})
end
